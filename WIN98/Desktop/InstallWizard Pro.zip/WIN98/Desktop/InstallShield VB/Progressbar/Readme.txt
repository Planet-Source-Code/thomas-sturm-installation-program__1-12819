Copyright: 2000, Kenneth Gilbert Jr.

Name: InstallBar
Author: Kenneth Gilbert Jr., masterkg@yahoo.com
Version: 1.0.2
Purpose:  Provide standard progress bar for all Visual Basic applications.

Properties:
-Backcolor,  the back color of the InstallBar control
-Forecolor,  the top color of the InstallBar control
-Percent,  the current percentage full of the the installbar control

How to Use:
-The precompiled version included with this readme was compiled using Visual Basic 6 Service Pack 4, under Windows 98 second edition. If you have any trouble, you may recompile the original code using your current installation of Visual Basic and Windows, assuming that support this.
-Any standard system OLE color is supported by the InstallBar.  The Back and Forecolor properties can be changed at design and run time.
-Backcolor and Forecolor default to colors under the current windows color theme
-Change the value of the Percent property to adjust the display of the Installbar.  It will automatically update its display based on the value of the Percent property
-For best results when testing, it is recommended that the kgbar102.ocx is placed in the System directory of your Windows installation